﻿namespace DeskMarket.Models.Output
{
    public class ProductDeleteViewModel
    {
        public int Id { get; set; }
        public string ProductName { get; set; }
        public string SellerId { get; set; }
        public string Seller { get; set; }
    }
}
